<?php
//Studi Kasus: Penjualan

//penjualan produk
//laptop
//aksesoris

class Produk{

}

produk1 = new Produk();
produk2 = new Produk();

?>