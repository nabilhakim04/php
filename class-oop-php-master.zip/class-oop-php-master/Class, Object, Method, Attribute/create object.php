<?php

class Hewan{
    var $jenisPemakan;
    var $jumlahKaki;

    function makan(){
         return "Nom nom nom";
    }
}

//membuat object dari class Hewan
$rusa = new Hewan();
$gajah = new Hewan();

>