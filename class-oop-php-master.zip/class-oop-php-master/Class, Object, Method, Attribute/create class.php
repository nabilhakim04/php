<?php

//Hewan merupakan nama Class-nya
class Hewan{
    //Isi class Hewan
}

>