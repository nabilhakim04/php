<?php

class Hewan{
    var $jenisPemakan;
    var $jumlahKaki;
}

>