<?php

class Hewan{
    var $jenisPemakan;
    var $jumlahKaki;

    //membuat metode makan
    function makan(){
         return "Nom nom nom";
    }
}

>